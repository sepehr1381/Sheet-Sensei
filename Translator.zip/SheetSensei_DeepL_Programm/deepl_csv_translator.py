# -*- coding: utf-8 -*-
r"""
DeepL CSV/TXT Translator – mit:
- Fester Arbeitsordner: C:\SheetSensei\SheetSensei_DeepL_Programm
- Spaltenauswahl (1-basiert, z.B. "2,4-6"; standardmäßig 2-999 = alles außer erster Spalte)
- Parallel-Übersetzung (3 Worker + sanftes Throttling)
- Fortschrittsbalken & Log ins UI + Datei
- Automatische Zeichensatz-Erkennung (chardet)
- Glossar-Manager: CSV (2 Spalten) -> DeepL-Glossar erstellen/löschen -> bei Übersetzung verwenden
- Glossar-Paar-Prüfung (unterstützte Sprachpaare werden vor Upload getestet)
- API-Key-Check & Usage
- HTML-Mode (tag_handling=html)
"""

import csv
import io
import logging
import os
import re
import threading
import time
import random
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

import requests
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk

try:
    import chardet  # pip install chardet
except Exception:
    chardet = None  # Fallback auf UTF-8
try:
    from win10toast import ToastNotifier  # pip install win10toast
except Exception:
    ToastNotifier = None


# ---------------- feste Pfade/Defaults ----------------
BASE_DIR = r"C:\SheetSensei\SheetSensei_DeepL_Programm"
os.makedirs(BASE_DIR, exist_ok=True)  # Arbeitsordner sicherstellen

APP_TITLE = "DeepL Document Translator (CSV/TXT)"
DEEPL_API_BASES = {"API Pro": "https://api.deepl.com", "API Free": "https://api-free.deepl.com"}

LANGS = [
    ("Auto erkennen", ""),
    ("Deutsch", "DE"),
    ("Englisch (US)", "EN-US"),
    ("Englisch (GB)", "EN-GB"),
    ("Französisch", "FR"),
    ("Italienisch", "IT"),
    ("Spanisch", "ES"),
    ("Niederländisch", "NL"),
    ("Polnisch", "PL"),
    ("Portugiesisch (PT)", "PT-PT"),
    ("Portugiesisch (BR)", "PT-BR"),
    ("Russisch", "RU"),
    ("Japanisch", "JA"),
    ("Chinesisch (vereinfacht)", "ZH"),
    ("Tschechisch", "CS"),
    ("Dänisch", "DA"),
    ("Griechisch", "EL"),
    ("Ungarisch", "HU"),
    ("Finnisch", "FI"),
    ("Schwedisch", "SV"),
    ("Bulgarisch", "BG"),
    ("Estnisch", "ET"),
    ("Lettisch", "LV"),
    ("Litauisch", "LT"),
    ("Slowakisch", "SK"),
    ("Slowenisch", "SL"),
    ("Rumänisch", "RO"),
]

MAX_WORKERS = 3                # konservativ, um Rate Limits zu schonen
BATCH_SIZE = 40                # Texte pro Request
THROTTLE_SECONDS = 0.15        # minimale Pause zwischen Requests pro Worker


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("980x660")

        # state
        self.file_path = tk.StringVar()
        self.api_key = tk.StringVar()
        self.source_lang = tk.StringVar(value=LANGS[1][0])  # Deutsch
        self.target_lang = tk.StringVar(value=LANGS[5][0])  # Italienisch
        self.api_env = tk.StringVar(value="API Pro")
        self.delimiter = tk.StringVar(value=";")
        self.quotechar = tk.StringVar(value='"')
        self.html_mode = tk.BooleanVar(value=False)
        self.columns_expr = tk.StringVar(value="2-999")  # alles außer erster Spalte
        self.write_logfile = tk.BooleanVar(value=True)
        self.output_dir = tk.StringVar(value="")

        # dynamisches Rate-Limit (Startwert, wird adaptiv angepasst)
        self._rl_delay = 0.5  # Sekunden
        self.toaster = ToastNotifier() if ToastNotifier else None


        # progress
        self.progress_total = 0
        self.progress_done = 0

        # glossary
        self.glossary_csv_path = tk.StringVar()
        self.use_glossary = tk.BooleanVar(value=False)
        self.glossary_id = tk.StringVar(value="")
        self.glossary_name = tk.StringVar(value="CSV-Glossar")

        # UI aufbauen; Logger wird am Ende von _build_ui() eingerichtet
        self._build_ui()

    # ---------------- UI ----------------
    def _build_ui(self):
        frm = ttk.LabelFrame(self, text="Eingaben")
        frm.pack(fill="x", padx=10, pady=10)

        # Datei
        ttk.Label(frm, text="Dateiname:").grid(row=0, column=0, sticky="w", padx=8, pady=6)
        ttk.Entry(frm, textvariable=self.file_path, width=60).grid(row=0, column=1, sticky="we", padx=4)
        ttk.Button(frm, text="Datei auswählen", command=self.choose_file).grid(row=0, column=2, padx=8)

        # Sprachen
        ttk.Label(frm, text="Quellsprache:").grid(row=1, column=0, sticky="w", padx=8, pady=2)
        ttk.Combobox(frm, textvariable=self.source_lang, values=[n for n, _ in LANGS], state="readonly", width=28)\
            .grid(row=1, column=1, sticky="w", padx=4)

        ttk.Label(frm, text="Zielsprache:").grid(row=2, column=0, sticky="w", padx=8, pady=2)
        ttk.Combobox(frm, textvariable=self.target_lang, values=[n for n, _ in LANGS if _], state="readonly", width=28)\
            .grid(row=2, column=1, sticky="w", padx=4)

        # CSV
        csvfrm = ttk.Frame(frm)
        csvfrm.grid(row=1, column=2, rowspan=2, padx=8, sticky="n")
        ttk.Label(csvfrm, text="CSV-Delimiter:").grid(row=0, column=0, sticky="w")
        ttk.Entry(csvfrm, textvariable=self.delimiter, width=4).grid(row=0, column=1, padx=4)
        ttk.Label(csvfrm, text="Quotechar:").grid(row=1, column=0, sticky="w", pady=2)
        ttk.Entry(csvfrm, textvariable=self.quotechar, width=4).grid(row=1, column=1, padx=4)
        ttk.Checkbutton(csvfrm, text="Inhalt ist HTML", variable=self.html_mode).grid(row=2, column=0, columnspan=2, pady=4)

        # Spaltenauswahl
        ttk.Label(frm, text="Spalten zum Übersetzen (1‑basiert, z.B. 2,4-6):").grid(row=3, column=0, sticky="w", padx=8, pady=6)
        ttk.Entry(frm, textvariable=self.columns_expr, width=32).grid(row=3, column=1, sticky="w", padx=4)
        ttk.Label(frm, text="Tipp: '2-999' = alles außer erster Spalte").grid(row=3, column=2, sticky="w")

        # API
        ttk.Label(frm, text="API-Key:").grid(row=4, column=0, sticky="w", padx=8, pady=6)
        ttk.Entry(frm, textvariable=self.api_key, width=40, show="•").grid(row=4, column=1, sticky="w", padx=4)
        ttk.Combobox(frm, textvariable=self.api_env, values=list(DEEPL_API_BASES.keys()), width=12, state="readonly")\
            .grid(row=4, column=2, sticky="w", padx=4)

        # Glossar
        gloss = ttk.LabelFrame(self, text="Glossar (optional)")
        gloss.pack(fill="x", padx=10, pady=6)
        ttk.Checkbutton(gloss, text="Glossar verwenden", variable=self.use_glossary).grid(row=0, column=0, sticky="w", padx=8, pady=4)
        ttk.Label(gloss, text="Glossar‑Name:").grid(row=0, column=1, sticky="e")
        ttk.Entry(gloss, textvariable=self.glossary_name, width=30).grid(row=0, column=2, sticky="w", padx=4)
        ttk.Label(gloss, text="Glossar‑CSV (2 Spalten):").grid(row=1, column=0, sticky="w", padx=8)
        ttk.Entry(gloss, textvariable=self.glossary_csv_path, width=60).grid(row=1, column=1, columnspan=2, sticky="we", padx=4)
        ttk.Button(gloss, text="Datei wählen", command=self.choose_glossary_csv).grid(row=1, column=3, padx=6)
        ttk.Button(gloss, text="An DeepL hochladen/aktualisieren", command=self.upload_glossary).grid(row=1, column=4, padx=6)
        ttk.Label(gloss, text="Glossary ID:").grid(row=2, column=0, sticky="w", padx=8, pady=4)
        ttk.Entry(gloss, textvariable=self.glossary_id, width=50, state="readonly").grid(row=2, column=1, columnspan=3, sticky="w", padx=4)
        ttk.Button(gloss, text="Glossar löschen", command=self.delete_glossary).grid(row=2, column=4, padx=6)

        # Zielordner
        outf = ttk.LabelFrame(self, text="Zielordner")
        outf.pack(fill="x", padx=10, pady=5)
        ttk.Entry(outf, textvariable=self.output_dir).pack(side="left", fill="x", expand=True, padx=8, pady=4)
        ttk.Button(outf, text="Ordner auswählen", command=self._choose_output_dir).pack(side="right", padx=8, pady=4)

        # Buttons
        btnfrm = ttk.Frame(self)
        btnfrm.pack(fill="x", padx=10)
        self.btn_start = ttk.Button(btnfrm, text="Start", command=self.start_translate, width=18)
        self.btn_start.pack(side="left", padx=6, pady=6)
        ttk.Button(btnfrm, text="API-Key prüfen", command=self.check_key, width=18).pack(side="left", padx=6, pady=6)
        ttk.Checkbutton(btnfrm, text="Log in Datei schreiben", variable=self.write_logfile).pack(side="right", padx=6)

        # Progress
        progfrm = ttk.Frame(self)
        progfrm.pack(fill="x", padx=10)
        self.progress = ttk.Progressbar(progfrm, orient="horizontal", mode="determinate", maximum=100)
        self.progress.pack(fill="x", padx=4, pady=4)

        # Log
        self.log = scrolledtext.ScrolledText(self, height=16, wrap="word")
        self.log.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        # Logger einrichten NACHDEM self.log existiert
        self._setup_logger()
        self._log("Bereit.")

    def _setup_logger(self):
        self.logger = logging.getLogger("deepl_csv_gui")
        self.logger.setLevel(logging.INFO)
        self.logger.handlers.clear()
        sh = logging.StreamHandler(self._TextWidgetWriter(self.log))
        sh.setLevel(logging.INFO)
        self.logger.addHandler(sh)

    class _TextWidgetWriter(io.TextIOBase):
        def __init__(self, widget):
            self.widget = widget

        def write(self, s):
            if not s.strip():
                return
            self.widget.insert("end", s if s.endswith("\n") else s + "\n")
            self.widget.see("end")

    def _file_logger(self, out_path):
        if not self.write_logfile.get():
            return None
        log_path = os.path.splitext(out_path)[0] + f"_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        fh = logging.FileHandler(log_path, encoding="utf-8")
        fh.setLevel(logging.INFO)
        self.logger.addHandler(fh)
        self.logger.info("Log-Datei: %s", log_path)
        return fh

    # --------------- helpers ---------------
    def _log(self, msg):
        self.logger.info("%s", msg)

    def _notify(self, title, msg, duration=5):
        """Zeigt eine Windows-Toast-Benachrichtigung (leise, falls nicht verfügbar)."""
        try:
            if self.toaster:
                text = msg if len(msg) <= 220 else (msg[:217] + "…")
                self.toaster.show_toast("SheetSensei", f"{title}: {text}", duration=duration, threaded=True)
        except Exception:
            pass



    def _api_base(self):
        return DEEPL_API_BASES[self.api_env.get()]

    def _headers(self):
        return {"Authorization": f"DeepL-Auth-Key {self.api_key.get().strip()}"}

    def _code_from_name(self, name):
        for n, c in LANGS:
            if n == name:
                return c
        return ""

    def _target_code(self):
        return self._code_from_name(self.target_lang.get())

    def _source_code(self):
        return self._code_from_name(self.source_lang.get())

    def choose_file(self):
        path = filedialog.askopenfilename(
            title="CSV oder TXT wählen",
            initialdir=BASE_DIR,
            filetypes=[("CSV/TXT", "*.csv *.txt *.tsv"), ("Alle Dateien", "*.*")]
        )
        if path:
            self.file_path.set(path)

    def choose_glossary_csv(self):
        path = filedialog.askopenfilename(
            title="Glossar CSV wählen (2 Spalten: Quelle;Ziel)",
            initialdir=BASE_DIR,
            filetypes=[("CSV/TSV", "*.csv *.tsv"), ("Alle Dateien", "*.*")]
        )
        if path:
            self.glossary_csv_path.set(path)

    def _choose_output_dir(self):
        path = filedialog.askdirectory(title="Zielordner wählen")
        if path:
            self.output_dir.set(path)


    # --------------- API: usage ---------------
    def check_key(self):
        if not self.api_key.get().strip():
            messagebox.showwarning("Fehlender API‑Key", "Bitte trage deinen DeepL‑API‑Key ein.")
            return
        threading.Thread(target=self._check_key_worker, daemon=True).start()

    def _check_key_worker(self):
        try:
            url = f"{self._api_base()}/v2/usage"
            r = requests.get(url, headers=self._headers(), timeout=20)
            if r.ok:
                d = r.json()
                self._log(f"API OK. Zeichen: {d.get('character_count')}/{d.get('character_limit')}")
                messagebox.showinfo("API‑Key", "API‑Key ist gültig.")
            else:
                self._log(f"API‑Fehler {r.status_code}: {r.text}")
                messagebox.showerror("API‑Fehler", r.text)
        except Exception as e:
            self._log(f"Netzwerkfehler: {e}")
            messagebox.showerror("Fehler", str(e))

    # -------- Glossary: unterstützte Sprachpaare abrufen --------
    def _get_supported_glossary_pairs(self):
        """
        Fragt bei DeepL die unterstützten Glossar-Sprachpaare ab.
        Rückgabe: set({("EN", "DE"), ("EN", "IT"), ...})
        """
        try:
            url = f"{self._api_base()}/v2/glossary-language-pairs"
            r = requests.get(url, headers=self._headers(), timeout=20)
            if not r.ok:
                self._log(f"Glossar-Paare konnten nicht geladen werden: {r.status_code} {r.text}")
                return set()
            data = r.json()
            # API liefert Liste in supported_language_pairs
            items = data.get("supported_language_pairs") or data.get("supported_languages") or data
            pairs = set()
            for item in items:
                src = item.get("source_lang") or item.get("source")
                tgt = item.get("target_lang") or item.get("target")
                if src and tgt:
                    pairs.add((src, tgt))
            return pairs
        except Exception as e:
            self._log(f"Glossar-Paare: Fehler bei der Abfrage: {e}")
            return set()

    # --------------- Glossary ---------------
    def upload_glossary(self):
        if not self.use_glossary.get():
            messagebox.showinfo("Glossar", "Aktiviere zuerst „Glossar verwenden“.")
            return
        if not self.api_key.get().strip():
            messagebox.showwarning("API‑Key", "Bitte trage deinen API‑Key ein.")
            return
        if not self.glossary_csv_path.get():
            messagebox.showwarning("Glossar", "Bitte eine Glossar‑CSV auswählen.")
            return

        # Quelle/Ziel holen – Glossare brauchen konkrete Codes (kein Auto)
        src = self._source_code()
        tgt = self._target_code()
        if not src:
            messagebox.showwarning("Glossar", "Bitte wähle eine konkrete Quellsprache (nicht 'Auto erkennen').")
            return
        if not tgt:
            messagebox.showwarning("Glossar", "Bitte wähle eine Zielsprache.")
            return

        # Unterstützte Paare prüfen
        pairs = self._get_supported_glossary_pairs()
        if pairs and (src, tgt) not in pairs:
            alternativen = sorted({p[1] for p in pairs if p[0] == src})
            alt_text = ", ".join(alternativen) if alternativen else "—"
            messagebox.showerror(
                "Glossar",
                "Dieses Sprachpaar wird für Glossare von DeepL nicht unterstützt.\n\n"
                f"Aktuell gewählt: {src} → {tgt}\n"
                f"Mögliche Zielsprachen für Quelle {src}: {alt_text}\n\n"
                "Tipp: Viele Glossar‑Paare sind mit Englisch als Quelle/Ziel verfügbar."
            )
            return

        try:
            entries_tsv = self._read_glossary_csv_as_tsv(self.glossary_csv_path.get())
            if not entries_tsv.strip():
                messagebox.showwarning("Glossar", "Glossar‑CSV ist leer.")
                return

            # vorhandenes Glossar ggf. löschen
            if self.glossary_id.get().strip():
                self.delete_glossary(silent=True)

            url = f"{self._api_base()}/v2/glossaries"
            data = {
                "name": self.glossary_name.get().strip() or f"Glossary-{int(time.time())}",
                "source_lang": src,
                "target_lang": tgt,
                "entries": entries_tsv,
                "entries_format": "tsv",
            }
            r = requests.post(url, headers=self._headers(), data=data, timeout=60)
            if r.ok:
                gid = r.json().get("glossary_id")
                self.glossary_id.set(gid or "")
                self._log(f"Glossar angelegt: {gid}")
                messagebox.showinfo("Glossar", f"Glossar angelegt (ID: {gid}).")
            else:
                self._log(f"Glossar-Fehler {r.status_code}: {r.text}")
                messagebox.showerror("Glossar", r.text)
        except Exception as e:
            self._log(f"Glossar-Fehler: {e}")
            messagebox.showerror("Glossar", str(e))

    def delete_glossary(self, silent=False):
        gid = self.glossary_id.get().strip()
        if not gid:
            if not silent:
                messagebox.showinfo("Glossar", "Kein Glossar gesetzt.")
            return
        try:
            url = f"{self._api_base()}/v2/glossaries/{gid}"
            r = requests.delete(url, headers=self._headers(), timeout=30)
            if r.status_code in (204, 200):
                self._log(f"Glossar gelöscht: {gid}")
                self.glossary_id.set("")
                if not silent:
                    messagebox.showinfo("Glossar", "Glossar gelöscht.")
            else:
                self._log(f"Glossar löschen fehlgeschlagen {r.status_code}: {r.text}")
                if not silent:
                    messagebox.showerror("Glossar", r.text)
        except Exception as e:
            self._log(f"Glossar-Fehler: {e}")
            if not silent:
                messagebox.showerror("Glossar", str(e))

    def _read_glossary_csv_as_tsv(self, path):
        # akzeptiert ; , oder TAB, 2 Spalten
        with open(path, "rb") as fb:
            raw = fb.read()
        enc = "utf-8"
        if chardet:
            det = chardet.detect(raw)
            if det and det.get("encoding"):
                enc = det["encoding"]
        text = raw.decode(enc, errors="replace")
        first_line = text.splitlines()[0] if text.splitlines() else ""
        delim = "\t" if "\t" in first_line else (";" if ";" in first_line else ",")
        out_lines = []
        for row in csv.reader(io.StringIO(text), delimiter=delim):
            if not row:
                continue
            if len(row) < 2:
                continue
            src = (row[0] or "").strip()
            tgt = (row[1] or "").strip()
            if not src or not tgt:
                continue
            out_lines.append(f"{src}\t{tgt}")
        return "\n".join(out_lines)

    # --------------- Übersetzung ---------------
    def start_translate(self):
        if not self.file_path.get().strip():
            messagebox.showwarning("Fehlende Datei", "Bitte wähle zuerst eine Datei.")
            return
        if not self.api_key.get().strip():
            messagebox.showwarning("Fehlender API‑Key", "Bitte trage deinen DeepL‑API‑Key ein.")
            return
        if not self._target_code():
            messagebox.showwarning("Zielsprache", "Bitte wähle eine Zielsprache.")
            return
        if self.use_glossary.get() and not self.glossary_id.get().strip():
            if not messagebox.askyesno(
                "Glossar",
                "„Glossar verwenden“ ist aktiv, aber keine Glossary‑ID gesetzt.\n"
                "Ohne ID wird übersetzt, jedoch ohne Glossar.\n\nFortfahren?"
            ):
                return
        self.btn_start.state(["disabled"])
        threading.Thread(target=self._translate_worker, daemon=True).start()

    def _translate_worker(self):
        path = self.file_path.get()
        in_name = os.path.splitext(os.path.basename(path))[0]
        target_dir = self.output_dir.get().strip() or BASE_DIR
        os.makedirs(target_dir, exist_ok=True)
        out_path = os.path.join(target_dir, f"{in_name}_translated_{self._target_code() or 'XX'}.csv")



        file_handler = self._file_logger(out_path)

        try:
            # Einlesen mit Encoding-Detection
            with open(path, "rb") as fb:
                raw = fb.read()
            enc = "utf-8"
            if chardet:
                det = chardet.detect(raw)
                if det and det.get("encoding"):
                    enc = det["encoding"]
            text = raw.decode(enc, errors="replace")
            self._log(f"Eingabe-Encoding erkannt als: {enc}")

            delim = self.delimiter.get() or ";"
            quote = (self.quotechar.get() or '"')[0]

            rows = list(csv.reader(io.StringIO(text), delimiter=delim, quotechar=quote))
            self.progress_total = len(rows)
            self.progress_done = 0
            self._update_progress()

            # Spaltenausdruck parsen (1-basiert)
            cols_to_translate = self._parse_columns_expr(self.columns_expr.get())
            self._log(f"Zu übersetzende Spalten (1-basiert): {sorted(cols_to_translate) or '—'}")
            if not cols_to_translate:
                self._log("Warnung: Keine Spalten ausgewählt – es wird nichts übersetzt.")

            # Parallelisierte Verarbeitung pro Zeile
            start = time.time()
            out_rows = [None] * len(rows)
            throttle = threading.Semaphore(MAX_WORKERS)  # zusätzlich begrenzen

            def work(i, row):
                with throttle:
                    return i, self._translate_row(row, cols_to_translate)

            # Bei Free stark begrenzen, um 429 zu vermeiden
            workers = 1 if self.api_env.get() == "API Free" else MAX_WORKERS
            with ThreadPoolExecutor(max_workers=workers) as ex:

                futures = [ex.submit(work, i, row) for i, row in enumerate(rows)]
                for fut in as_completed(futures):
                    i, new_row = fut.result()
                    out_rows[i] = new_row
                    self.progress_done += 1
                    if self.progress_done % 50 == 0:
                        self._log(f"{self.progress_done}/{self.progress_total} Zeilen …")
                    self._update_progress()

            # Schreiben
            with open(out_path, "w", encoding="utf-8", newline="") as f_out:
                writer = csv.writer(f_out, delimiter=delim, quotechar=quote, quoting=csv.QUOTE_MINIMAL)
                for r in out_rows:
                    writer.writerow(r)

            elapsed = time.time() - start
            self._log(f"Fertig! Datei gespeichert: {out_path}  (Dauer: {elapsed:.1f}s)")
            messagebox.showinfo("Erfolg", f"Übersetzung abgeschlossen.\n\n{out_path}")
            self._notify("Übersetzung fertig", out_path)

        except Exception as e:
            self._log(f"Fehler: {e}")
            messagebox.showerror("Fehler", str(e))
            self._notify("Übersetzung fehlgeschlagen", str(e))

        finally:
            if file_handler:
                self.logger.removeHandler(file_handler)
                file_handler.close()
            self.btn_start.state(["!disabled"])
            self.progress["value"] = 0

    def _update_progress(self):
        if self.progress_total <= 0:
            self.progress["value"] = 0
            return
        val = int(100 * (self.progress_done / self.progress_total))
        self.progress["value"] = max(0, min(100, val))
        self.update_idletasks()

    def _parse_columns_expr(self, expr):
        # Ausdruck wie "2,4-6,10" -> set({2,4,5,6,10})
        out = set()
        expr = (expr or "").strip()
        if not expr:
            return out
        for part in re.split(r"\s*,\s*", expr):
            if not part:
                continue
            if "-" in part:
                a, b = part.split("-", 1)
                try:
                    a, b = int(a), int(b)
                    if a > b:
                        a, b = b, a
                    out.update(range(a, b + 1))
                except ValueError:
                    pass
            else:
                try:
                    out.add(int(part))
                except ValueError:
                    pass
        return out

    def _translate_row(self, row, cols_to_translate):
        if not row:
            return row
        to_idx = [c - 1 for c in cols_to_translate if 1 <= c <= len(row)]
        if not to_idx:
            return row

        original = [row[i] for i in to_idx]
        translated_all = []

        for i in range(0, len(original), BATCH_SIZE):
            chunk = original[i:i + BATCH_SIZE]
            translated = self._translate_batch(chunk)
            if translated is None:
                translated = chunk  # Fallback
            translated_all.extend(translated)
            time.sleep(max(0.05, getattr(self, "_rl_delay", 0.5) / 3))


        out = list(row)
        for idx, val in zip(to_idx, translated_all):
            out[idx] = val
        return out
    def _translate_batch(self, texts):
        if not texts:
            return []
        params = {"target_lang": self._target_code()}
        src = self._source_code()
        if src:
            params["source_lang"] = src
        if self.html_mode.get():
            params["tag_handling"] = "html"
        if self.use_glossary.get() and self.glossary_id.get().strip():
            params["glossary_id"] = self.glossary_id.get().strip()

        url = f"{self._api_base()}/v2/translate"
        data = [("text", t if t is not None else "") for t in texts]

        # Retry-Loop mit exponentiellem Backoff + Jitter (keine Rekursion)
        delay = max(0.2, getattr(self, "_rl_delay", 0.5))
        for attempt in range(1, 8):  # bis zu 7 Versuche
            try:
                r = requests.post(url, headers=self._headers(), data=data, params=params, timeout=60)
                # 429/503 => Backoff
                if r.status_code in (429, 503):
                    self._log(f"Rate-Limit erreicht, warte {delay:.1f}s … (Versuch {attempt})")
                    time.sleep(delay + random.uniform(0, 0.4))  # Jitter
                    # Backoff verschärfen, aber Deckel setzen
                    delay = min(delay * 1.8, 8.0)
                    self._rl_delay = delay  # merken, damit künftige Calls entspannter starten
                    continue

                if r.status_code >= 400:
                    self._log(f"API‑Fehler {r.status_code}: {r.text}")
                    return None

                payload = r.json()
                # Erfolg → Delay leicht abbauen (schneller werden, aber sanft)
                self._rl_delay = max(0.2, self._rl_delay * 0.7)
                return [item["text"] for item in payload.get("translations", [])]

            except requests.RequestException as e:
                self._log(f"Netzwerkfehler: {e} — warte {delay:.1f}s")
                time.sleep(delay + random.uniform(0, 0.4))
                delay = min(delay * 1.8, 8.0)

        # alle Versuche fehlgeschlagen
        self._log("Übersetzung nach mehreren Versuchen fehlgeschlagen.")
        return None


if __name__ == "__main__":
    app = App()
    app.mainloop()
