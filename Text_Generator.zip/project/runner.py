import os
import time
from typing import Optional, List, Dict
from openai import OpenAI
import openpyxl

# ===== Datei- und Sheet-Settings =====
XLSX_PATH    = r"C:\SheetSensei\project\SheetSensei.xlsx"  # <-- Anpassen!
SHEET_NAME   = None          # None = 1. Blatt; sonst z. B. "Daten"
CONFIG_SHEET = "Config"      # Blattname für globale Einstellungen

# ===== Spaltenbelegung =====
COL_CAT3    = "A"
COL_CAT4    = "B"
COL_SKU     = "C"
COL_TITLE   = "D"
COL_URL     = "E"
COL_PROMPT  = "F"
COL_KW      = "G"
COL_MODEL   = "H"
COL_DESC    = "I"
COL_FB      = "J"
COL_COUNT   = "K"
COL_STATUS  = "L"

# ===== Defaults =====
FALLBACK_MODEL = "gpt-4o-mini"
TEMP = 0.6
SLEEP_BETWEEN = 0.25

# ===== API-Key prüfen =====
api_key = os.getenv("OPENAI_API_KEY")
if not api_key or not api_key.startswith("sk-") or len(api_key) < 20:
    raise RuntimeError(
        "OPENAI_API_KEY fehlt oder ist ungültig.\n"
        "Bitte in CMD setzen:  setx OPENAI_API_KEY \"sk-...\"  und CMD neu starten."
    )

client = OpenAI(api_key=api_key)

# ===== Helpers =====
def effective(v: Optional[str]) -> str:
    return "" if v is None else str(v).strip()

def set_status(ws, row: int, text: str):
    ws[f"{COL_STATUS}{row}"] = text

def get_config(ws_cfg) -> tuple[str, str, int]:
    """B2=System-Prompt, B3=Default-Modell, B4=Batch-Limit."""
    sys_prompt = ""
    default_model = FALLBACK_MODEL
    batch_size = 10
    if ws_cfg is not None:
        if ws_cfg["B2"].value:
            sys_prompt = str(ws_cfg["B2"].value)
        if ws_cfg["B3"].value:
            default_model = str(ws_cfg["B3"].value)
        if ws_cfg["B4"].value:
            try:
                batch_size = int(ws_cfg["B4"].value)
            except Exception:
                batch_size = 10
    if batch_size < 1:
        batch_size = 1
    return sys_prompt, default_model, batch_size

def build_messages(system_prompt: str,
                   row_prompt: str,
                   feedback: str,
                   cat3: str, cat4: str, sku: str,
                   title: str, url: str, keywords: str) -> List[Dict]:
    """System-Prompt aus Config, User-Prompt dynamisch pro Zeile."""
    user_parts = []

    # Zusatzvorgaben aus Spalte F
    if row_prompt:
        user_parts.append(f"Zusatzvorgaben: {row_prompt}")

    # Feedback bei Rewrite
    if feedback:
        user_parts.append(f"Bitte überarbeite die Beschreibung unter Berücksichtigung dieses Feedbacks: {feedback}")

    # Keywords-Anweisung
    if keywords:
        user_parts.append(
            f"Folgende Keywords sind manuell vorgegeben und müssen "
            f"jeweils genau einmal (maximal zweimal bei sehr wenigen Keywords) "
            f"natürlich und sinnvoll in die Beschreibung eingebaut werden: {keywords}"
        )

    # Kerndaten aus der Zeile
    ctx = [
        f"Kategorie Ebene 3: {cat3}",
        f"Kategorie Ebene 4: {cat4}",
        f"Artikelnummer: {sku}",
        f"Artikelname: {title}",
        f"Produkt-URL: {url}",
    ]
    user_parts.append("Kontext:\n" + "\n".join(ctx))

    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": "\n\n".join(user_parts)},
    ]
def generate_text(model: str, messages: List[Dict]) -> str:
    resp = client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=TEMP,
    )
    return resp.choices[0].message.content.strip()

# ===== Main =====
def main():
    wb = openpyxl.load_workbook(XLSX_PATH)
    ws = wb.worksheets[0] if SHEET_NAME is None else wb[SHEET_NAME]
    ws_cfg = wb[CONFIG_SHEET] if CONFIG_SHEET in wb.sheetnames else None

    system_prompt, default_model, batch_size = get_config(ws_cfg)

    row = 2
    processed = 0

    while True:
        if processed >= batch_size:
            break

        # Kernfelder lesen
        cat3   = effective(ws[f"{COL_CAT3}{row}"].value)
        cat4   = effective(ws[f"{COL_CAT4}{row}"].value)
        sku    = effective(ws[f"{COL_SKU}{row}"].value)
        title  = effective(ws[f"{COL_TITLE}{row}"].value)
        url    = effective(ws[f"{COL_URL}{row}"].value)
        row_prompt = effective(ws[f"{COL_PROMPT}{row}"].value)
        keywords   = effective(ws[f"{COL_KW}{row}"].value)
        model_cell = effective(ws[f"{COL_MODEL}{row}"].value)
        desc       = effective(ws[f"{COL_DESC}{row}"].value)
        feedback   = effective(ws[f"{COL_FB}{row}"].value)
        cnt        = ws[f"{COL_COUNT}{row}"].value or 0

        # Ende bei komplett leerer Datenzeile
        if not any([cat3, cat4, sku, title, url, row_prompt, keywords, desc, feedback]):
            set_status(ws, row, "SKIPPED_EMPTY")
            break

        model = model_cell or default_model or FALLBACK_MODEL

        should_generate = False
        rewrite = False
        if not desc and (row_prompt or title or sku or keywords):
            should_generate = True
        if feedback:
            should_generate = True
            rewrite = True

        if should_generate:
            try:
                msgs = build_messages(system_prompt, row_prompt,
                                      feedback if rewrite else "",
                                      cat3, cat4, sku, title, url, keywords)
                new_text = generate_text(model, msgs)
                ws[f"{COL_DESC}{row}"] = new_text
                ws[f"{COL_COUNT}{row}"] = int(cnt) + 1
                set_status(ws, row, "DONE_REWRITE" if rewrite else "DONE_NEW")
                processed += 1
                if processed >= batch_size:
                    break
            except Exception as e:
                ws[f"{COL_DESC}{row}"] = f"[Fehler] {e}"
                set_status(ws, row, f"ERROR: {e}")
            time.sleep(SLEEP_BETWEEN)
        else:
            set_status(ws, row, "SKIPPED_HAS_DESC")

        row += 1

    wb.save(XLSX_PATH)
    print(f"Fertig. {processed} Zeile(n) verarbeitet (Limit: {batch_size}).")

if __name__ == "__main__":
    main()
